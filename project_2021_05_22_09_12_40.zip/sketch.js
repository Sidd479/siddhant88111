//global variables
var bananaImage,obstaclesImage;
var obstaclesgroup,background,score;

function preload(){
  backgroundImage=loadImage("jungle.jpg");
  player_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaImage=loadImage("banana.png");
  obstacle_img=loadImage("stone.png");
  
  
}

function spawnScore(){
 switch(score){
    
   case 10: player.scale=0.12
     break;
     case 10: player.scale=0.14
     break;
      case 10: player.scale=0.16
     break;
      case 10: player.scale=0.18
   default: break;  
 }
 
}









function setup() {
  createCanvas(400, 400);
  if(obstaclesGroup.isTouching(player)){
    
    player.scale=0.2
  }
  
  
  
}

function draw() {
  background(220);
}